﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour {

    public void LoadLevel(string level)
    {
        Application.LoadLevel(1);
    }
}
