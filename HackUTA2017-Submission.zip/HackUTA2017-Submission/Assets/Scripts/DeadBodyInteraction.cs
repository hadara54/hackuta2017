﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeadBodyInteraction : MonoBehaviour
{
    public Text interactText;
    public Text deathDescriptionText;

    GameObject PlayerGO;


    private void Start()
    {
        interactText = GameObject.Find("InteractionText").GetComponent<Text>();
        deathDescriptionText = GameObject.Find("deathDescriptionText").GetComponent<Text>();
        PlayerGO = GameObject.FindGameObjectWithTag("Player");
    }

    private void Update()
    {
        if (deathDescriptionText.enabled == true && Input.GetKeyDown(KeyCode.H))
        {
            deathDescriptionText.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.H) && deathDescriptionText.enabled == false)
        {
            interactText.enabled = false;
            deathDescriptionText.enabled = true;
            PlayerGO.GetComponent<PlayerMovement>().hasReadDead = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && deathDescriptionText.enabled != true)
        {
            interactText.enabled = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (deathDescriptionText.enabled != true)
            interactText.enabled = false;
        else
            deathDescriptionText.enabled = false;
    }

}
