﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MailBoxScript : MonoBehaviour
{
    GameObject PlayerGO;

	// Use this for initialization
	void Start ()
    {
        PlayerGO = GameObject.FindGameObjectWithTag("Player");	
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && PlayerGO.GetComponent<PlayerMovement>().hasReadDead)
        {
            int i = Application.loadedLevel;
            if (i < 4)
                Application.LoadLevel(i + 1);
            else
                Application.LoadLevel(0);
        }
    }
}
